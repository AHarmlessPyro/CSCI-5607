## Build and misc info

To Build, run

  `make`

To clean, run

  `make clean`

The app will generate an executable called `Assignment1.exe`.

It can be run with `./Assignment1.exe {inputFilePath}` . This should generate a
file called `{inputFileName}.ppm`.

### About

The program will generate a netpbm format image that resembles a face without
a mouth with the default input file.

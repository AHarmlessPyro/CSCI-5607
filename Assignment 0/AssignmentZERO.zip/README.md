## Build and misc info

To Build, run

  `make`

To clean, run

  `make clean`

The app will generate an executable called `Assignment0.exe`.

It can be run with `./Assignment0.exe -{inputFilePath}` . This should generate a
file called `Output.ppm`. If no input file is supplied, default values of 999x
999 pixels would be taken.

### About

The program will generate a netpbm format image that resembles a circle,
essentially a color picker like circle with black borders to fill the remaining
portions outside the region of the circle.
